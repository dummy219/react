import './App.css'

function App() {
  return (
    <>
      <div className="row">

        {/* LEFT CONTAINER */}
        <div className="col-xs-12 col-md-8" id='left-container'>

          <h1 className='welcome-text'>welcome back bob!</h1>
          <h4 className='day'>today</h4>

          <div className='target-container'>

            <div className='week-tracker'>
              <h6 className='week-text'>week</h6>
              <h2 className='week-number'>4</h2>
              <h6 className='week-text2'>of 10</h6>
            </div>

            <div className='week-average'>
              <h6 className='average-text'>week average</h6>
              <h2 className='average-number'>62</h2>
              <h6 className='average-text2'>kg</h6>
            </div>

            <div className='week-target'>
              <h6 className='target-text'>week 4 target</h6>
              <h2 className='target-number'>61</h2>
              <h6 className='target-text2'>kg</h6>
            </div>



          </div>
        </div>

        {/* RIGHT CONTAINER */}
        <div className="col-xs-6 col-md-4" id='right-container'>
          {/* Content for right container */}
        </div>

      </div>
    </>
  )
}

export default App;
